function addition(n1,n2)
{
    return (n1+n2)
}


function substract(n1,n2)
{
    let sub= n1-n2
    return sub
}


function multiply(n1,n2)
{
    let mult= n1*n2
    return mult
}


export default addition; // default export

export {substract,multiply};// Naming export