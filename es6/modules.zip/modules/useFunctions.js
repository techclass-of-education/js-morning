import sum, { substract, multiply } from "./allFunctions.js"; // ./ current folder

import factorial from "./moreFunction.js";

import { evenOdd } from "./moreFunction.js";

let add = sum(4, 2);

alert(add);

let sub = substract(2, 5);

alert(sub);

let mult = multiply(4, 8);

alert(mult);

let f = factorial(6);
alert(f);

let n = 6;
let r = evenOdd(n);

if (r) {
  alert(n + " is even");
} else {
  alert(n + " is odd");
}
